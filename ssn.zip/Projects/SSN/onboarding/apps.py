from django.apps import AppConfig


class OnboardingConfig(AppConfig):
    name = 'onboarding'
