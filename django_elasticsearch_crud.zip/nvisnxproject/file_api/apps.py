from django.apps import AppConfig


class FileApiConfig(AppConfig):
    name = 'file_api'
