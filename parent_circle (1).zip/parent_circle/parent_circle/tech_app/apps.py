from django.apps import AppConfig


class TechAppConfig(AppConfig):
    name = 'tech_app'
