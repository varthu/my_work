import React, { Component } from "react";
 
class Home extends Component {
  render() {
    return (
        <div className="right_col" role="main">
            <div id="root">Test mee Pos</div>
      </div>
    )
  }
}

export default Home